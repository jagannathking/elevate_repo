import React, { useEffect, useState } from "react";

const App = () => {
  const [formData, setFormData] = useState({
    data: "",
    solt: "",
  });

 const [allData, setAllData] = useState([]);
 const [day ,setDay] = useState('');
 const [error, setError] = useState({});
 const [isValid, setIsValid] = useState(false);


  const handleUserData = (e) => {
    const {name, value} = e.target;
    console.log(e.target.value)
    setFormData({...formData, [name] : value})
  };


  const handleSubmit = (e) => {
    e.preventDefault();

    setAllData([...allData, formData])
     
    let key = formData.data;
    let value = formData.solt;

    const store = localStorage.setItem(key,value)
  };
  
  
  const validation = () => {


    if(formData.data === 0 || formData.data === 2 ||
      formData.data === 3 || formData.data === 4 || formData.data === 6
    ){

      setIsValid(true)
      setError("Data are not valid")
      
    }

    
  }


  useEffect(() => {
    validation()
  }, [formData]);


  // create time
  useEffect(() => {
    let timer = setInterval(() => {
      const now = new Date();

      const day = String(now.getDate());
      
      setDay(day)
    }, 1000);

    return () => clearTimeout(timer);
  }, []);

  console.log("day",day)

  //
  const solts = [
    "9.30 AM",
    "10.00 AM",
    "10.30 AM",
    "11.30 AM",
    "12.00 PM",
    "12.30 PM",
    "3.00 PM",
    "3.30 PM",
    "4.00 PM",
    "4.30 PM",
    "5.00 PM",
    "5.30 PM",
    "6.00 PM",
    "6.30 PM",
    "7.00 PM",
    "7.30 PM",
    "8.00 PM",
    "8.30 PM",
  ];

  return (
    <div>

      <h1>Form</h1>
      <div>
        {
          isValid && error? <p>{error.data}</p> : ""
        }
      </div>
      <div>
        <form onSubmit={handleSubmit}>
          <div>
            <input
              type="date"
              value={formData.data}
              onChange={handleUserData}
            />
          </div>

          <div>
            <select value={formData.solt} onChange={handleUserData}>
              <option value="">select</option>
              {solts &&
                solts.map((solt, index) => <option key={index} value={solt}>{solt}</option>)}

        
            </select>
          </div>

          <div>
            <button type="submit" disabled={isValid === true}>Submit</button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default App;
